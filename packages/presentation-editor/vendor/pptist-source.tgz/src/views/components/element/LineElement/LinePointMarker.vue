<template>
  <marker 
    :id="`${id}-${type}-${position}`" 
    markerUnits="userSpaceOnUse" 
    orient="auto" 
    :markerWidth="size * 3" 
    :markerHeight="size * 3" 
    :refX="refX" 
    :refY="refY"
  >
		<path 
      :d="path" 
      :fill="color"
      :transform="`scale(${size * 0.3}, ${size * 0.3}) rotate(${rotate}, 5, 5)`"
    ></path>
	</marker>
</template>

<script lang="ts" setup>
import { computed } from 'vue'
import type { LinePoint } from '@/types/slides'

type NonEmptyLinePoint = Exclude<LinePoint, ''>

const props = defineProps<{
  id: string
  position: 'start' | 'end'
  type: NonEmptyLinePoint
  baseSize: number
  color?: string
  preview?: boolean
}>()

const pathMap = {
  dot: 'm0 5a5 5 0 1 0 10 0a5 5 0 1 0 -10 0z',
  arrow: 'M0,0 L10,5 0,10 Z',
}
const rotateMap: Record<string, number> = {
  'arrow-start': 180,
  'arrow-end': 0,
}

const path = computed(() => pathMap[props.type])
const rotate = computed(() => rotateMap[`${props.type}-${props.position}`] || 0)
const size = computed(() => props.baseSize < 2 ? 2 : props.baseSize)
const refX = computed(() => {
  if (props.preview) return size.value * 1.5
  if (props.position === 'start') return 0
  return size.value * 3
})
const refY = computed(() => size.value * 1.5)
</script>
